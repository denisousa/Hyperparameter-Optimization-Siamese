This list of abbreviations was extracted from SCOWL (Spell Checker Oriented Word Lists) by by Kevin Atkinson (kevina@gnu.org) version 2015.04.24.

Specifically it was created from scowl-2015.04.24.tar.gz. by running:

cat *abbrev* | sort -u

It also contains some additions by D.M German.

See Copyright.scowl for license.
