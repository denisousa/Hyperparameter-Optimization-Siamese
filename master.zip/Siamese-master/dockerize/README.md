# Instruction
1. Install docker on host
2. Edit docker-compose.yml as needed
3. Run command `docker-compose up`
4. Done!

# Update docker image to docker registry
[Link is here](https://stackoverflow.com/questions/28349392/how-to-push-a-docker-image-to-a-private-repository)